<!-- begin:: Footer -->
<div class="kt-footer kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop">
						<div class="kt-footer__copyright">
							{{date("Y")}}&nbsp;&copy;&nbsp;<a href="{{route('admin.dashboard')}}"  class="kt-link">{{ config('app.name', 'Laravel') }} </a>
						</div>
						<div class="kt-footer__menu">
							{{-- <a href="#"  class="kt-footer__menu-link kt-link">About</a>
							<a href="#"  class="kt-footer__menu-link kt-link">Team</a>
							<a href="#"  class="kt-footer__menu-link kt-link">Contact</a> --}}
						</div>
					</div>

					<!-- end:: Footer -->