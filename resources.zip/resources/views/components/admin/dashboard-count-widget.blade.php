 <div class="kt-widget1">
    {{ $slot }}
 </div>