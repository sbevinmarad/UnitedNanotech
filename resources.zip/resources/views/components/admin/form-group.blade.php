<div {!! $attributes->merge(['class' => 'form-group col-lg-6']) !!}>
        {{ $slot }}
</div>