@props(['value'=>"",'text'=>"Please select one",'selected'=>false])
<option value="{{$value}}" selected="{{$selected }}" > {{$text}}</option>